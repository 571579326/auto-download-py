CREATE DATABASE IF NOT EXISTS `auto_download`
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

USE `auto_download`;

DROP TABLE IF EXISTS `ad_browser_page`;
DROP TABLE IF EXISTS `ad_browser_window`;
DROP TABLE IF EXISTS `ad_browser_session`;

CREATE TABLE `ad_browser_window` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
  `window_id` VARCHAR(64) NOT NULL COMMENT '业务窗口ID',
  `status` CHAR(1) NOT NULL DEFAULT '1' COMMENT '1有效 0失效',
  `last_page_title` VARCHAR(255) DEFAULT NULL COMMENT '最后一次激活页面标题',
  `last_page_url` VARCHAR(500) DEFAULT NULL COMMENT '最后一次激活页面URL',
  `created_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `invalid_time` DATETIME DEFAULT NULL COMMENT '失效时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_window_id` (`window_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='浏览器窗口表';

CREATE TABLE `ad_browser_page` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
  `window_id` BIGINT NOT NULL COMMENT '所属窗口主键',
  `title` VARCHAR(255) DEFAULT NULL COMMENT '页面标题',
  `url` VARCHAR(1000) DEFAULT NULL COMMENT '页面URL',
  `status` CHAR(1) NOT NULL DEFAULT '1' COMMENT '0打开但非激活 1当前激活 2失效',
  `sort_no` INT NOT NULL DEFAULT 1 COMMENT '窗口内页面顺序号',
  `created_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `invalid_time` DATETIME DEFAULT NULL COMMENT '失效时间',
  PRIMARY KEY (`id`),
  KEY `idx_window_status` (`window_id`, `status`),
  KEY `idx_window_sort` (`window_id`, `sort_no`),
  CONSTRAINT `fk_ad_browser_page_window_id` FOREIGN KEY (`window_id`) REFERENCES `ad_browser_window` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='浏览器页面表';
