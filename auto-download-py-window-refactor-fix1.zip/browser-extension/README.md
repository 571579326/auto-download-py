# browser-extension

这里预留给后续的 Chrome 扩展版本。

后续会在这里增加：

- tabs / windows / tabGroups 采集
- 页面工作区快照上报
- 浏览器恢复任务轮询
- 分组恢复
