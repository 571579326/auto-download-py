# AGENT.md

## 项目定位

`auto-download-py` 是一个 **浏览器 + 桌面 + 图像** 的混合自动化项目，要求同时满足两种调用方式：

1. **本地接口层**：本地 Python 业务代码直接 import 并调用 service
2. **HTTP API 层**：FastAPI 路由只做参数接收与 service 转调

## 当前架构

- `app/browser/manager.py`
  - 浏览器运行时与会话管理
  - Playwright + CDP
  - 页面列表、激活、关闭、接管、Bing 示例
- `app/desktop/windows_manager.py`
  - Windows 窗口枚举与激活
  - 基于 `pywinauto`
- `app/visual/screen_manager.py`
  - 坐标点击、按图点击、OCR 预留
  - 基于 `pyautogui`
- `app/services/*.py`
  - 本地业务代码直接调用入口
- `app/api/*.py`
  - HTTP 路由层，只负责调用 service

## 扩展规则

### 浏览器能力

新增浏览器能力时按顺序改：

1. `app/browser/manager.py`
2. `app/services/browser_service.py`
3. `app/api/browser.py`（仅在需要 HTTP 暴露时）

### 桌面能力

新增窗口/桌面控件能力时按顺序改：

1. `app/desktop/windows_manager.py`
2. `app/services/desktop_service.py`
3. `app/api/desktop.py`

### 图像/屏幕能力

新增图片点击/OCR/坐标能力时按顺序改：

1. `app/visual/screen_manager.py`
2. `app/services/visual_service.py`
3. `app/api/desktop.py`

## 不要做的事情

- 不要让业务代码直接 import `app.api.*`
- 不要让 API 层直接写数据库
- 不要在 API 层写浏览器/桌面核心逻辑
- 不要把桌面坐标点击和浏览器 DOM 操作混在一个 manager 里
- 不要把 `SessionLocal()` 暴露给上层业务

## 本版本边界

### 已完成

- 浏览器 service + API 双层结构
- 桌面 service + API 双层结构
- 图像/屏幕 service + API 双层结构
- OCR 点击接口预留
- uv 安装说明与脚本

### 未默认完成

- cnOCR 真正接入
- 桌面层持久化落库
- 多会话多浏览器并发调度
- 浏览器外部文件上传/另存为完整编排

## 当前推荐测试顺序

1. `/health`
2. `/browser/session/open`
3. `/browser/pages`
4. `/browser/close`
5. `/desktop/windows`
6. `/desktop/window/activate`
7. `/desktop/keyboard/type`
8. `/desktop/click/pos`
9. `/desktop/click/image`

## 日志排查建议

浏览器打开失败时，优先查看这些关键日志：

- `open_session开始`
- `浏览器进程已启动`
- `CDP已就绪`
- `数据库会话已写入`
- `sync_playwright启动成功`
- `connect_over_cdp成功`

如果失败，当前代码会尽量把 Chrome 提前退出、CDP 未就绪、Playwright 挂接失败的异常打印完整。
