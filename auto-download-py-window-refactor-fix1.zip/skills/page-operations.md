# page-operations skill

## pageId 规则

当前页面 ID 使用 `page-{index}`，例如：

- `page-1`
- `page-2`
- `page-3`

这是会话内顺序 ID，不是永久稳定 ID。

## 页面定位优先级

- 传 `pageId`：优先按 `pageId`
- 否则传 `urlContains`：按 URL 模糊匹配
- 都不传：默认取当前 active / 最近页面

## 当前 active 页来源

以下操作会更新 active page：

- 新建标签页
- 显式 bring to front
- takeover 页面
- activate 页面

## 适用场景

适合列表页后立即激活/关闭目标页。若后续需要更强的跨时间稳定标识，再升级 page 标识策略。
