# browser-service skill

## 目标

让本地 Python 业务代码像调用 service 一样调用浏览器能力，同时保留 HTTP API 暴露能力。

## 关键文件

- `app/browser/manager.py`
- `app/services/browser_service.py`
- `app/api/browser.py`

## 当前方法

- `open_browser()`
- `new_tab()`
- `open_url()`
- `list_pages()`
- `get_page_info()`
- `takeover_page_info()`
- `activate_page()`
- `close_page()`
- `bing_huya()`
- `close_browser()`

## 扩展顺序

先加 manager，再加 service，最后再决定要不要加 API。

## 注意

FastAPI 路由层是 `async`，但浏览器 service 是同步的，所以 API 层必须使用 `run_in_threadpool()` 转调，避免在 asyncio loop 里直接执行 Playwright Sync API。
