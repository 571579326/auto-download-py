# skills

本目录存放给后续维护者或自动化代理使用的技能说明。

- `browser-service.md`：浏览器 service / API / manager 的关系
- `page-operations.md`：标签页与页面定位规则
- `desktop-service.md`：桌面窗口、键盘、坐标点击扩展说明
- `visual-service.md`：模板图点击与 OCR 预留说明
