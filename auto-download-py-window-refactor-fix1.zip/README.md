# auto-download-py

这是一个 **Python 3.11 / Windows 10** 的混合自动化项目初始化版，目标是同时支持：

- **浏览器自动化**：Playwright + CDP，支持接管已打开的 Chromium 浏览器，也支持程序自己启动浏览器
- **桌面自动化**：标准 Windows 窗口/控件激活、键盘输入、快捷键
- **图像/屏幕自动化**：按屏幕坐标点击、按模板图片查找并点击
- **本地接口层**：业务代码直接 `import service` 调用
- **HTTP API 层**：FastAPI 仅做薄封装，直接转调本地 service

本版本会尽量保留你当前已有的浏览器功能需求，并在此基础上新增桌面层与图像层骨架。

---

## 1. 当前能力

### 浏览器层

已保留并可继续扩展：

- 打开浏览器会话 `open_browser()` / `POST /browser/session/open`
- 新建标签页 `new_tab()` / `POST /browser/tab/open`
- 在指定页或新标签页打开 URL `open_url()` / `POST /browser/page/open-url`
- 获取标签页列表 `list_pages()` / `GET /browser/pages`
- 获取页面信息 `get_page_info()` / `GET /browser/page-info`
- 激活标签页 `activate_page()` / `POST /browser/page/activate`
- 关闭标签页 `close_page()` / `POST /browser/page/close`
- Bing 搜索并打开虎牙链接 `bing_huya()` / `POST /browser/bing-huya`
- 接管最近页面信息 `takeover_page_info()` / `GET /browser/takeover/page-info`
- 关闭会话 `close_browser()` / `POST /browser/close`

### 桌面层

新增：

- 列出桌面窗口 `list_windows()` / `GET /desktop/windows`
- 激活指定窗口 `activate_window()` / `POST /desktop/window/activate`
- 输入文本 `type_text()` / `POST /desktop/keyboard/type`
- 发送组合键 `hotkey()` / `POST /desktop/keyboard/hotkey`

### 图像/屏幕层

新增：

- 按屏幕坐标点击 `click_position()` / `POST /desktop/click/pos`
- 按模板图查找并点击 `click_image()` / `POST /desktop/click/image`
- OCR 点击接口预留 `ocr_click_text_reserved()` / `POST /desktop/click/ocr-text`
  - 当前只返回预留说明
  - 你后续可接入 **cnOCR** 实现

---

## 2. 目录结构

```text
app/
  api/
    browser.py          # 浏览器 HTTP API
    desktop.py          # 桌面/屏幕 HTTP API
    health.py
  browser/
    manager.py          # Playwright + CDP 浏览器运行时与会话管理
  desktop/
    windows_manager.py  # pywinauto 窗口管理
  visual/
    screen_manager.py   # pyautogui + 图像查找点击
  core/
    config.py
    logging_config.py
  db/
    base.py
    session.py
  models/
    browser_session.py
  schemas/
    browser.py
    desktop.py
    common.py
  services/
    browser_service.py  # 本地浏览器 service
    desktop_service.py  # 本地桌面 service
    visual_service.py   # 本地图像/屏幕 service
scripts/
  local_service_demo.py
  demo_browser.py
  demo_desktop.py
  demo_hybrid.py
  smoke_test.py
skills/
  browser-service.md
  page-operations.md
  desktop-service.md
  visual-service.md
AGENT.md
```

---

## 3. 运行前准备（uv 方式）

### 3.1 创建虚拟环境

```bash
uv venv
```

Windows PowerShell：

```powershell
.venv\Scripts\Activate.ps1
```

Windows CMD：

```bat
.venv\Scripts\activate.bat
```

### 3.2 安装依赖

主流程：

```bash
uv sync
```

如果你不想用 `uv sync`，也可以：

```bash
uv pip install -r requirements.txt
```

### 3.3 安装 Playwright 浏览器支持

```bash
uv run playwright install chrome
```

如果你使用的是本机已有的 `chrome-win64`，仍然建议执行一次上面的命令，以确保 Playwright 依赖完整。

---

## 4. `.env` 配置

复制：

```bat
copy .env.example .env
```

默认已经按你的环境预设成：

- Python 3.11
- Windows 10
- APP_PORT=7982
- DEBUG_PORT=29222
- BROWSER_EXECUTABLE_PATH=`C:/software/chrome-win64/chrome.exe`
- PROFILE_DIR=`C:/cache/chromeTest/auto-download/shared-profile`

重点检查这些配置：

- `DB_HOST`
- `DB_PORT`
- `DB_NAME`
- `DB_USER`
- `DB_PASSWORD`
- `BROWSER_EXECUTABLE_PATH`
- `PROFILE_DIR`
- `DEBUG_PORT`

> 当前 SQL 默认数据库名是 `auto_download`。如果你本地实际使用的是其他名字，请同步修改 `.env` 中的 `DB_NAME`。

---

## 5. 初始化数据库

执行：

```sql
source sql/auto_download.sql;
```

当前只保留浏览器会话表：

- `ad_browser_session`

本次没有新增桌面层持久化表。桌面与图像层默认不落库。

---

## 6. 启动

### 开发模式

```bash
uv run uvicorn app.main:app --host 0.0.0.0 --port 7982 --reload
```

或直接运行：

```bat
scripts\run_dev.bat
```

### 生产/普通模式

```bash
uv run uvicorn app.main:app --host 0.0.0.0 --port 7982
```

或：

```bat
scripts\run_prod.bat
```

---

## 7. API 一览

### 7.1 浏览器 API

#### 打开浏览器会话

```http
POST /auto-download/browser/session/open
```

#### 新建标签页

```http
POST /auto-download/browser/tab/open?sessionId=xxxx
Content-Type: application/json

{
  "url": "https://www.bing.com",
  "bringToFront": true
}
```

#### 打开 URL

```http
POST /auto-download/browser/page/open-url?sessionId=xxxx
Content-Type: application/json

{
  "url": "https://www.example.com",
  "pageId": "page-1",
  "newTab": false,
  "bringToFront": true
}
```

#### 页面列表

```http
GET /auto-download/browser/pages?sessionId=xxxx
```

#### 页面信息

```http
GET /auto-download/browser/page-info?sessionId=xxxx&pageId=page-1
GET /auto-download/browser/page-info?sessionId=xxxx&urlContains=bing
```

#### 激活页面

```http
POST /auto-download/browser/page/activate?sessionId=xxxx&pageId=page-2
```

#### 关闭页面

```http
POST /auto-download/browser/page/close?sessionId=xxxx&pageId=page-2
```

#### Bing 搜索并打开虎牙

```http
POST /auto-download/browser/bing-huya?sessionId=xxxx
Content-Type: application/json

{
  "keyword": "虎牙直播lpl",
  "targetPrefix": "https://www.huya.com"
}
```

#### 接管页面信息

```http
GET /auto-download/browser/takeover/page-info?sessionId=xxxx&urlContains=huya
```

#### 关闭浏览器会话

```http
POST /auto-download/browser/close?sessionId=xxxx
```

### 7.2 桌面 API

#### 列出窗口

```http
GET /auto-download/desktop/windows?backend=uia&titleContains=Chrome&onlyVisible=true&limit=20
```

#### 激活窗口

```http
POST /auto-download/desktop/window/activate
Content-Type: application/json

{
  "backend": "uia",
  "titleRegex": ".*Chrome.*",
  "timeoutMs": 5000,
  "restoreIfMinimized": true
}
```

#### 坐标点击

```http
POST /auto-download/desktop/click/pos
Content-Type: application/json

{
  "x": 500,
  "y": 300,
  "clicks": 1,
  "button": "left"
}
```

#### 图片点击

```http
POST /auto-download/desktop/click/image
Content-Type: application/json

{
  "imagePath": "C:/temp/target.png",
  "confidence": 0.9,
  "regionLeft": 0,
  "regionTop": 0,
  "regionWidth": 1920,
  "regionHeight": 1080,
  "timeoutMs": 5000,
  "retryIntervalMs": 400
}
```

#### 输入文本

```http
POST /auto-download/desktop/keyboard/type
Content-Type: application/json

{
  "text": "hello",
  "intervalSeconds": 0.02
}
```

#### 组合键

```http
POST /auto-download/desktop/keyboard/hotkey
Content-Type: application/json

{
  "keys": ["ctrl", "l"],
  "intervalSeconds": 0.0
}
```

#### OCR 点击预留接口

```http
POST /auto-download/desktop/click/ocr-text
Content-Type: application/json

{
  "text": "确定",
  "contains": true,
  "confidence": 0.5,
  "timeoutMs": 5000,
  "retryIntervalMs": 400
}
```

---

## 8. 本地代码直接调用示例

### 浏览器 service

```python
from app.schemas.browser import NewTabRequest
from app.services.browser_service import browser_service

opened = browser_service.open_browser()
session_id = opened.sessionId
page = browser_service.new_tab(session_id, NewTabRequest(url='https://www.bing.com'))
print(page)
```

### 桌面 service

```python
from app.schemas.desktop import ActivateWindowRequest, WindowQueryRequest
from app.services.desktop_service import desktop_service

windows = desktop_service.list_windows(WindowQueryRequest(titleContains='Chrome'))
print(windows)

# desktop_service.activate_window(ActivateWindowRequest(titleRegex='.*Chrome.*'))
```

### 图像/屏幕 service

```python
from app.schemas.desktop import ClickImageRequest
from app.services.visual_service import visual_service

# visual_service.click_image(ClickImageRequest(imagePath='C:/temp/target.png'))
```

---

## 9. 示例脚本

### 浏览器本地调用示例

```bash
uv run python scripts/local_service_demo.py

或：

```bash
uv run python scripts/demo_browser.py
```
```

### 桌面本地调用示例

```bash
uv run python scripts/demo_desktop.py
```

### 浏览器 + 桌面混合示例

```bash
uv run python scripts/demo_hybrid.py
```

### HTTP smoke test

```bash
uv run python scripts/smoke_test.py
```

---

## 10. 关于 OCR / cnOCR

你要求的 OCR 点击先预留接口，这一版已经完成：

- schema 已有
- service 已有
- API 已有
- README 已有调用方式

但默认不安装 `cnocr`，也没有强行集成 OCR 引擎。后续你要接入时，推荐走这条链路：

1. 截图指定区域
2. 用 `cnOCR` 识别文本框
3. 算出点击位置
4. 用 `visual_service.click_position()` 或 pywinauto 完成最终点击

---

## 11. 当前技术选型说明

### 为什么浏览器不用纯 RPA 框架替代

因为当前主线仍然是浏览器自动化，并且你还要接管已存在的 Chromium 浏览器。`Playwright + CDP` 更适合作为浏览器主引擎。

### 为什么桌面层单独拆 service

因为桌面控件、屏幕坐标、图片匹配与网页 DOM 是两种能力，拆开后更容易维护，也更适合你后续在本地业务代码中直接调用。

---

## 12. 注意事项

1. **桌面自动化当前按 Windows 设计**。
2. `pyautogui` 默认启用 `FAILSAFE`，鼠标快速移动到屏幕左上角可触发安全中断。
3. 图片点击对分辨率、缩放、主题、窗口遮挡较敏感。
4. 当前页面 `pageId` 是会话内顺序 ID，例如 `page-1`、`page-2`。
5. 如果 `POST /browser/session/open` 失败，请先看日志，当前版本已经补充了更完整的 Chrome 启动、CDP 就绪、Playwright 挂接日志。

---

## 13. 后续建议

后续你可以继续在这版上加：

- 元素点击/输入（网页 DOM）
- 截图与下载跟踪
- OCR 真正实现（cnOCR）
- 文件上传/另存为弹窗编排
- 桌面层窗口树查询增强
- 图片点击失败截图落盘
- 混合流程编排 service
